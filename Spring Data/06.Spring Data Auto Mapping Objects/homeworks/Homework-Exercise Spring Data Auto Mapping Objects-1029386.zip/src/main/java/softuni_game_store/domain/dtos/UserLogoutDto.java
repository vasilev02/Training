package softuni_game_store.domain.dtos;

public class UserLogoutDto {
    private String fullName;

    public UserLogoutDto() {
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
