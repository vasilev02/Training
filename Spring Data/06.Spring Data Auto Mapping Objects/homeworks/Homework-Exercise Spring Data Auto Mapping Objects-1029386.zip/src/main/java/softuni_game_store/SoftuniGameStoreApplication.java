package softuni_game_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftuniGameStoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftuniGameStoreApplication.class, args);
    }

}
