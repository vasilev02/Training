package softuni_game_store.domain.dtos;

public class OwnedGameDto {
    private String title;

    public OwnedGameDto() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
