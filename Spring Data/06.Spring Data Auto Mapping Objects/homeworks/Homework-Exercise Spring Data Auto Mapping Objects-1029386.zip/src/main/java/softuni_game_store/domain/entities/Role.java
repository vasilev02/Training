package softuni_game_store.domain.entities;

public enum Role {
    ADMIN,
    USER
}
