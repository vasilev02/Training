package gameshop.demo.services;


import gameshop.demo.domain.dtos.UserLoginDto;
import gameshop.demo.domain.dtos.UserRegisterDto;
import gameshop.demo.domain.entities.User;
import org.springframework.stereotype.Service;

public interface UserService {

    String registerUser(UserRegisterDto userRegisterDto);

    String loginUser(UserLoginDto userLoginDto);
}
