package gameshop.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameShopExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(GameShopExerciseApplication.class, args);
    }

}
