package gameshop.demo.domain.dtos;

import org.springframework.context.annotation.Bean;


public class UserDto {


    private String fullName;
    private String password;


    public UserDto() {
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

