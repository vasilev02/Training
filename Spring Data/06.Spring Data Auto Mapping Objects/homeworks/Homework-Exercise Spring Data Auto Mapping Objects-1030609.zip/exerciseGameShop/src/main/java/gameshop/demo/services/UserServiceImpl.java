package gameshop.demo.services;

import gameshop.demo.domain.dtos.UserDto;
import gameshop.demo.domain.dtos.UserLoginDto;
import gameshop.demo.domain.dtos.UserRegisterDto;
import gameshop.demo.domain.entities.Role;
import gameshop.demo.domain.entities.User;
import gameshop.demo.repositories.UserRepository;
import gameshop.demo.utils.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import java.util.Optional;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {


    private final ValidatorUtil validatorUtil;
    private final ModelMapper modelmapper;
    private final UserRepository userRepository;
    private UserDto loggedUser;

    @Autowired
    public UserServiceImpl(ValidatorUtil validatorUtil, ModelMapper modelmapper, UserRepository userRepository ) {
        this.validatorUtil = validatorUtil;
        this.modelmapper = modelmapper;
        this.userRepository = userRepository;


    }

    @Override
    public String registerUser(UserRegisterDto userRegisterDto) {
        StringBuilder sb = new StringBuilder();

        if (!(userRegisterDto.getConfirmPassword().equals(userRegisterDto.getPassword()))) {
            sb.append("Passwords dont match");
        } else if (validatorUtil.isValid(userRegisterDto)) {
            User user = this.modelmapper.map(userRegisterDto, User.class);
            if (this.userRepository.count() == 0) {
                user.setRole(Role.ADMIN);
            } else {
                user.setRole(Role.USER);
            }
            sb.append(String.format("%s was registered", userRegisterDto.getFullName()));
            this.userRepository.saveAndFlush(user);
        } else {
            Set<ConstraintViolation<UserRegisterDto>> violations = this.validatorUtil.violations(userRegisterDto);

            violations.forEach(e -> sb.append(String.format("%s\n", e.getMessage())));
        }

        return sb.toString().trim();
    }

    @Override
    public String loginUser(UserLoginDto userLoginDto) {
        StringBuilder sb = new StringBuilder();

        Optional<User> user =
                this.userRepository.findByEmailAndPassword(userLoginDto.getEmail(), userLoginDto.getPassword());

        if (user.isPresent()) {

            if (this.loggedUser != null) {
                sb.append("User is already logged in!");

            } else {
                this.loggedUser = this.modelmapper.map(user.get(), UserDto.class);
                sb.append(String.format("Successfully logged in %s", user.get().getFullName()));

            }


        } else {
            sb.append("Incorrect mail / password");
        }


        return sb.toString().trim();
    }

}
