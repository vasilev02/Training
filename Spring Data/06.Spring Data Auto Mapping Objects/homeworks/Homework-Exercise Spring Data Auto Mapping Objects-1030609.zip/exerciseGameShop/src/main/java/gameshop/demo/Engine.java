package gameshop.demo;

import gameshop.demo.domain.dtos.UserLoginDto;
import gameshop.demo.domain.dtos.UserRegisterDto;
import gameshop.demo.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@Component
public class Engine implements CommandLineRunner {

    private final UserService userService;

    @Autowired
    public Engine(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void run(String... args) throws Exception {

        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Input:");
        String[] tokens = bf.readLine().split("\\|");


        switch (tokens[0]) {

            case "RegisterUser":
                UserRegisterDto registerDto = new UserRegisterDto(tokens[1], tokens[2], tokens[3], tokens[4]);

                System.out.println(this.userService.registerUser(registerDto));

                break;

            case "LoginUser":
                UserLoginDto loginDto   = new UserLoginDto();

                System.out.println(this.userService.loginUser(loginDto));
                break;
        }


        System.err.println("SHUTDOWN");
        System.exit(1);
    }
}
