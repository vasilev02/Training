package gameshop.demo.domain.entities;

public enum Role {

    ADMIN,USER
}
