package com.example.demo.domain.entities;

public enum Size {

    SMALL, MEDIUM, LARGE;
}
