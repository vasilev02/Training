package com.softuni.springintroex.constants;

public class GlobalConstants {
    public static final String AUTHORS_FILE_PATH =
            "";
    public static final String BOOKS_FILE_PATH =
            "";
    public static final String CATEGORIES_FILE_PATH =
            "";
}
