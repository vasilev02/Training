package hiberspring.repository;


public interface ProductRepository{
}
