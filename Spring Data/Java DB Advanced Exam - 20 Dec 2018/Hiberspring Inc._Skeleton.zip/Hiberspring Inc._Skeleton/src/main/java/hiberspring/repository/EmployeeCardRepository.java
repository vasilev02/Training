package hiberspring.repository;

//TODO
public interface EmployeeCardRepository  {

}
