package hiberspring.common;

public final class GlobalConstants {

    //TODO
    public static final String BRANCHES_FILE_PATH = "";
    public static final String EMPLOYEE_CARDS_FILE_PATH = "";
    public static final String EMPLOYEES_FILE_PATH = "";
    public static final String PRODUCTS_FILE_PATH = "";
    public static final String TOWNS_FILE_PATH = "";

    public final static String INCORRECT_DATA_MESSAGE = "Error: Invalid Data!";

    public final static String SUCCESSFUL_IMPORT_MESSAGE = "Successfully imported %s %s.";
}
