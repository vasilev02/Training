package hiberspring.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
