package hiberspring.repository;

//TODO
public interface EmployeeRepository {
}
