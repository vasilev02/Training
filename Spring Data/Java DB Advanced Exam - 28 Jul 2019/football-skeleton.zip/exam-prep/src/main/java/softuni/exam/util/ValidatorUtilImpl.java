package softuni.exam.util;



public class ValidatorUtilImpl implements ValidatorUtil {

 

    @Override
    public <E> boolean isValid(E entity) {
       return false;
    }



}
