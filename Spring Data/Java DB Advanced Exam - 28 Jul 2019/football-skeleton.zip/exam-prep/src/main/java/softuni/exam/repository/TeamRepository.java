package softuni.exam.repository;



public interface TeamRepository  {

}
