package softuni.exam.repository;


public interface PictureRepository  {


}
