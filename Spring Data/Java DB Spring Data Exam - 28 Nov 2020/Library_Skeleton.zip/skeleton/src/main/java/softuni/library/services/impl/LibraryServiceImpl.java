package softuni.library.services.impl;

import softuni.library.services.LibraryService;

public class LibraryServiceImpl implements LibraryService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readLibrariesFileContent() {
        return null;
    }

    @Override
    public String importLibraries() {
        return null;
    }
}
