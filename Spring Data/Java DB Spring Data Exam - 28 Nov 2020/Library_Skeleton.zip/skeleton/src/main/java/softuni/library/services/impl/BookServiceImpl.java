package softuni.library.services.impl;

import softuni.library.services.BookService;

public class BookServiceImpl implements BookService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readBooksFileContent() {
        return null;
    }

    @Override
    public String importBooks() {
        return null;
    }
}
