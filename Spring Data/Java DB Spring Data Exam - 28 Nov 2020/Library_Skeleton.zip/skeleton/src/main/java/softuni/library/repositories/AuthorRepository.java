package softuni.library.repositories;

public interface AuthorRepository {
}
