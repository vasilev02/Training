package softuni.library.services.impl;

import softuni.library.services.AuthorService;

public class AuthorServiceImpl implements AuthorService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readAuthorsFileContent() {
        return null;
    }

    @Override
    public String importAuthors() {
        return null;
    }
}
