package softuni.library.repositories;

public interface BookRepository {
}
