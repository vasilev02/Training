package com.example.demo.util;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileUtil {

    String readFileContent(String path) throws IOException;

}
