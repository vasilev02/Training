package softuni.exam.instagraphlite.repository;

public interface UserRepository {
}
