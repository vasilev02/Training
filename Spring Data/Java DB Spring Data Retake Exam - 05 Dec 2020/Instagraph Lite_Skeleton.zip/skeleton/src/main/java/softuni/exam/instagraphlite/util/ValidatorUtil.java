package softuni.exam.instagraphlite.util;

public interface ValidatorUtil {
    <T> boolean isValid(T entity);
}
