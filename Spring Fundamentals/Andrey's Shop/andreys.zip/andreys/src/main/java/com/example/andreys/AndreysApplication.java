package com.example.andreys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AndreysApplication {

	public static void main(String[] args) {
		SpringApplication.run(AndreysApplication.class, args);
	}

}
