package com.example.andreys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AndreysApplicationTests {

	@Test
	void contextLoads() {
	}

}
