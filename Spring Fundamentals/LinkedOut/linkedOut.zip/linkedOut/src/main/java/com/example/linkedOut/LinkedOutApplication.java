package com.example.linkedOut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinkedOutApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinkedOutApplication.class, args);
	}

}
