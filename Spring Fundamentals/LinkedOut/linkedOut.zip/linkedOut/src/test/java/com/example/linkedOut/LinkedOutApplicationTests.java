package com.example.linkedOut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedOutApplicationTests {

	@Test
	void contextLoads() {
	}

}
