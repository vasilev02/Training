package com.example.gira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiraApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiraApplication.class, args);
	}

}
